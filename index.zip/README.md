# Aplicación de mapas para página turistica

Esta es una demo de una posible manera de mostrar rutas en mapas gracias al poder de la API de Google Maps